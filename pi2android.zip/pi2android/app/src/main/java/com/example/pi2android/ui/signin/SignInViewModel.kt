package com.example.pi2android.ui.signin

import androidx.lifecycle.ViewModel

class SignInViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}